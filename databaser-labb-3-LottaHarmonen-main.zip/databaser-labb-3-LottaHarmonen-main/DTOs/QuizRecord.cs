﻿namespace DTOs;

public record QuizRecord(string id, string quizTitle, string quizDescription);


